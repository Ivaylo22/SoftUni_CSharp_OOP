﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Models.Food
{
    public class Fruit : Food
    {
        public Fruit(int quantity) 
            : base(quantity)
        {
        }
    }
}
