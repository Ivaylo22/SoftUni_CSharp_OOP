﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony.Models.Core
{
    public interface IEngine
    {
        void Start();
    }
}
